assert.sameValue(Number("1_0123456789"), NaN, "1_0123456789");
