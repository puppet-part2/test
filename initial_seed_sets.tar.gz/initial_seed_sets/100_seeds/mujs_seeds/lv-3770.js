try {
  var s1 = {
    x: 1
  };
  s1.toString = Boolean.prototype.toString;
  var v1 = s1.toString();
  $ERROR('#1: Boolean.prototype.toString on not a Boolean object should throw TypeError');
}
catch (e) {
  if (!(e instanceof TypeError)) {
    $ERROR('#1: Boolean.prototype.toString on not a Boolean object should throw TypeError, not ' + e);
  }
}
try {
  var s2 = {
    x: 1
  };
  s2.myToString = Boolean.prototype.toString;
  var v2 = s2.myToString();
  $ERROR('#2: Boolean.prototype.toString on not a Boolean object should throw TypeError');
}
catch (e) {
  if (!(e instanceof TypeError)) {
    $ERROR('#2: Boolean.prototype.toString on not a Boolean object should throw TypeError, not ' + e);
  }
}
