assert.throws(TypeError, function() {
  WeakSet.prototype.delete.call({}, {});
});
assert.throws(TypeError, function() {
  var s = new WeakSet();
  s.delete.call({}, {});
});
