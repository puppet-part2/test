`${tunz}\x

// https://code.google.com/p/v8/issues/detail?id=3820
