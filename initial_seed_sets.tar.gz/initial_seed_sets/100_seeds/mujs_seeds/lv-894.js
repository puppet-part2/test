(function() {
  Object.defineProperty(arguments, "0", {
    value: 0,
    writable: false,
    enumerable: true,
    configurable: false
  });
  try {
    Object.defineProperty(arguments, "0", {
      enumerable: false
    });
    $ERROR("Expected an exception.");
  } catch (e) {
    verifyEqualTo(arguments, "0", 0);
    verifyNotWritable(arguments, "0");
    verifyEnumerable(arguments, "0");
    verifyNotConfigurable(arguments, "0");
    if (!(e instanceof TypeError)) {
      $ERROR("Expected TypeError, got " + e);
    }
  }
}());
