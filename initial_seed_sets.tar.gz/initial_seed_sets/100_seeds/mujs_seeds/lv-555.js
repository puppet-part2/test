var arr = [0, 1, 2];
var expected = ["0", "1", "2", "length"];
var actual = Object.getOwnPropertyNames(arr);
assert(compareArray(actual, expected), 'compareArray(actual, expected) !== true');
