delete Number.prototype.toString;
var obj = new Number();
if (obj.toString() !== "[object Number]") {
  $ERROR('#1: The [[Class]] property of the newly constructed object is set to "Number"');
}
