testWithBigIntTypedArrayConstructors(function(TA) {
  var sample = new TA([42n, 43n]);
  Object.preventExtensions(sample);
  assert.sameValue(Reflect.defineProperty(sample, "foo", {value:42}), false);
  assert.sameValue(Reflect.getOwnPropertyDescriptor(sample, "foo"), undefined);
  var s = Symbol("1");
  assert.sameValue(Reflect.defineProperty(sample, s, {value:42}), false);
  assert.sameValue(Reflect.getOwnPropertyDescriptor(sample, s), undefined);
});
