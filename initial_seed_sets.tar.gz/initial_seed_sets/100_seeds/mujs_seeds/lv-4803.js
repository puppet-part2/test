var s = Symbol("1");
testWithTypedArrayConstructors(function(TA) {
  assert.throws(TypeError, function() {
    TA.of(s);
  });
});
