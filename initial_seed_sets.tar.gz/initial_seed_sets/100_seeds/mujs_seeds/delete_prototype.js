delete new Object().prototype[0];
