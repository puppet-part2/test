eval("(function() { return  1.2e3 | -3/0 % false; })()")
