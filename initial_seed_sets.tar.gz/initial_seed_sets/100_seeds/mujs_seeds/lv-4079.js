var s = new Set([1]);
assert.throws(TypeError, function() {
  s.forEach(0);
});
