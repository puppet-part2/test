if (typeof Number.prototype !== "object") {
  $ERROR('#1: typeof Number.prototype === "object"');
}
Number.prototype.toString = Object.prototype.toString;
if (Number.prototype.toString() !== "[object Number]") {
  $ERROR('#3: The [[Class]] property of the Number prototype object is set to "Number"');
}
