const i32a = new Int32Array(
  new SharedArrayBuffer(Int32Array.BYTES_PER_ELEMENT * 4)
);
assert.sameValue(
  Atomics.notify(i32a, 0, -3),
  0,
  'Atomics.notify(i32a, 0, -3) returns 0'
);
assert.sameValue(
  Atomics.notify(i32a, 0, Number.POSITIVE_INFINITY),
  0,
  'Atomics.notify(i32a, 0, Number.POSITIVE_INFINITY) returns 0'
);
assert.sameValue(
  Atomics.notify(i32a, 0, undefined),
  0,
  'Atomics.notify(i32a, 0, undefined) returns 0'
);
assert.sameValue(
  Atomics.notify(i32a, 0, '33'),
  0,
  'Atomics.notify(i32a, 0, \'33\') returns 0'
);
assert.sameValue(
  Atomics.notify(i32a, 0, { valueOf: 8 }),
  0,
  'Atomics.notify(i32a, 0, {valueOf: 8}) returns 0'
);
assert.sameValue(
  Atomics.notify(i32a, 0),
  0,
  'Atomics.notify(i32a, 0) returns 0'
);
