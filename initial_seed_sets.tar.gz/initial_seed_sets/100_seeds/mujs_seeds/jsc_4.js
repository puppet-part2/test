(function() {
var a;
(function() {
for(var i = 0; i < 10000; i++);
a
})();
})();

// https://bugs.webkit.org/show_bug.cgi?id=141194
