assert.sameValue(JSON.stringify(42, function(k, v) {
  return v == 42 ? [4, 2] : v
}), '[4,2]', 'JSON.stringify(42, function(k, v) { return v==42 ?[4,2]:v })');
