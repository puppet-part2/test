var proto = {};
Object.defineProperty(proto, "prop", {
  value: 11,
  configurable: true
});
var Con = function() {};
Con.prototype = proto;
var obj = new Con();
Object.defineProperty(obj, "prop", {
  get: function() {
    return 12;
  },
  configurable: false
});
assert.throws(TypeError, function() {
  Object.defineProperties(obj, {
    prop: {
      value: 13,
      configurable: true
    }
  });
});
assert.sameValue(obj.prop, 12, 'obj.prop');
