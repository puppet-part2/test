var obj = {};
Object.defineProperty(obj, "property", {
  writable: true,
  enumerable: true,
  configurable: false
});
verifyEqualTo(obj, "property", undefined);
verifyWritable(obj, "property");
verifyEnumerable(obj, "property");
verifyNotConfigurable(obj, "property");
