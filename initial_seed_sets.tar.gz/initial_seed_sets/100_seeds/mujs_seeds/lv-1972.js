assert.throws(TypeError, function() {
  Object.create({}, {
    prop: {
      get: function() {},
      value: 100
    }
  });
});
