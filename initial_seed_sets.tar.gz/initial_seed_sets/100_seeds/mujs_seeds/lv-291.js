verifyNotEnumerable(Number, "isNaN");
verifyWritable(Number, "isNaN");
verifyConfigurable(Number, "isNaN");
