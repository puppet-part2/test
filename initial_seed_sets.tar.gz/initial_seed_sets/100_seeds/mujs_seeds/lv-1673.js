var obj = {};
Object.defineProperty(obj, false, {});
assert(obj.hasOwnProperty("false"), 'obj.hasOwnProperty("false") !== true');
