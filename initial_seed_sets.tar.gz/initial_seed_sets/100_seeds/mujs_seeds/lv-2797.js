var obj = {};
Object.defineProperties(obj, {
  property: {
    configurable: new SyntaxError()
  }
});
var preCheck = obj.hasOwnProperty("property");
delete obj.property;
assert(preCheck, 'preCheck !== true');
assert.sameValue(obj.hasOwnProperty("property"), false, 'obj.hasOwnProperty("property")');
