JSON.writable = true;
var newObj = Object.create({}, {
  prop: JSON
});
var beforeWrite = (newObj.hasOwnProperty("prop") && typeof(newObj.prop) === "undefined");
newObj.prop = "isWritable";
var afterWrite = (newObj.prop === "isWritable");
assert.sameValue(beforeWrite, true, 'beforeWrite');
assert.sameValue(afterWrite, true, 'afterWrite');
