a = function(){};
__defineSetter__("0", function(){});
if(a|= ''){};
this[a].__parent__;
