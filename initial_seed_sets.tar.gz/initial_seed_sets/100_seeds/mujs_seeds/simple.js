function a() {}
function b() {}
b.prototype = a;
new b();
