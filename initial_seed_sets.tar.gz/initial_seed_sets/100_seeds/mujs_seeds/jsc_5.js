new 
function f() {
for (f in [1])({})();
}

// https://bugs.webkit.org/show_bug.cgi?id=141187
