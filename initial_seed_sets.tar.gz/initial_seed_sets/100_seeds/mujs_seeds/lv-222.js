if (Number.prototype.toString(4) !== "0") {
  $ERROR('#1: Number.prototype.toString(4) === "0"');
}
if ((new Number()).toString(4) !== "0") {
  $ERROR('#2: (new Number()).toString(4) === "0"');
}
if ((new Number(0)).toString(4) !== "0") {
  $ERROR('#3: (new Number(0)).toString(4) === "0"');
}
if ((new Number(-1)).toString(4) !== "-1") {
  $ERROR('#4: (new Number(-1)).toString(4) === "-1"');
}
if ((new Number(1)).toString(4) !== "1") {
  $ERROR('#5: (new Number(1)).toString(4) === "1"');
}
if ((new Number(Number.NaN)).toString(4) !== "NaN") {
  $ERROR('#6: (new Number(Number.NaN)).toString(4) === "NaN"');
}
if ((new Number(Number.POSITIVE_INFINITY)).toString(4) !== "Infinity") {
  $ERROR('#7: (new Number(Number.POSITIVE_INFINITY)).toString(4) === "Infinity"');
}
if ((new Number(Number.NEGATIVE_INFINITY)).toString(4) !== "-Infinity") {
  $ERROR('#8: (new Number(Number.NEGATIVE_INFINITY)).toString(4) === "-Infinity"');
}
