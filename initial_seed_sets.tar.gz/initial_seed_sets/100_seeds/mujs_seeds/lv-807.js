(function() {
  delete arguments[0];
  Object.defineProperty(arguments, "0", {
    value: 10,
    writable: false,
    enumerable: false,
    configurable: false
  });
  verifyEqualTo(arguments, "0", 10);
  verifyNotWritable(arguments, "0");
  verifyNotEnumerable(arguments, "0");
  verifyNotConfigurable(arguments, "0");
}(0, 1, 2));
