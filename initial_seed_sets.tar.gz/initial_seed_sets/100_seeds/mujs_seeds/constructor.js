(function* () { }).constructor()
