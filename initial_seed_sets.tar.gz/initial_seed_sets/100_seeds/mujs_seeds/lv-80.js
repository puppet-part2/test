if (!Number.hasOwnProperty("NaN")) {
  $ERROR('#1: The Number constructor has the property "NaN"');
}
