var arrObj = [];
function getFunc() {
  return 12;
}
Object.defineProperty(arrObj, "0", {
  get: undefined,
  configurable: true
});
Object.defineProperty(arrObj, "0", {
  get: getFunc
});
verifyEqualTo(arrObj, "0", getFunc());
verifyNotEnumerable(arrObj, "0");
verifyConfigurable(arrObj, "0");
