var obj = {};
Object.defineProperty(obj, "foo", {
  value: 100,
  enumerable: true,
  writable: false,
  configurable: true
});
Object.defineProperties(obj, {
  foo: {
    writable: true
  }
});
verifyEqualTo(obj, "foo", 100);
verifyWritable(obj, "foo");
verifyEnumerable(obj, "foo");
verifyConfigurable(obj, "foo");
