assert.throws(RangeError, function() {
  new ArrayBuffer(9007199254740992);
}, "`length` parameter is too large");
assert.throws(RangeError, function() {
  new ArrayBuffer(Infinity);
}, "`length` parameter is positive Infinity");
