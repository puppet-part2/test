assert.sameValue(
  Object.values.name,
  'values',
  'Expected Object.values.name to be "values"'
);
verifyNotEnumerable(Object.values, 'name');
verifyNotWritable(Object.values, 'name');
verifyConfigurable(Object.values, 'name');
