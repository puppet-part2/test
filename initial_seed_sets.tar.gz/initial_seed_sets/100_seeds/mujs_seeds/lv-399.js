assert.sameValue(JSON.parse('"\\/"'), '/', 'JSON.parse(\'"\\/"\')');
