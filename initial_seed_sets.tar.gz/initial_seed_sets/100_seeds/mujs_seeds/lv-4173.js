testWithTypedArrayConstructors(function(TA) {
  var sample = new TA();
  sample.buffer.constructor = 1;
  assert.throws(TypeError, function() {
    new TA(sample);
  });
  sample.buffer.constructor = true;
  assert.throws(TypeError, function() {
    new TA(sample);
  });
  sample.buffer.constructor = '';
  assert.throws(TypeError, function() {
    new TA(sample);
  });
  sample.buffer.constructor = null;
  assert.throws(TypeError, function() {
    new TA(sample);
  });
  var s = Symbol('1');
  sample.buffer.constructor = s;
  assert.throws(TypeError, function() {
    new TA(sample);
  });
});
