var __FACTORY = String.prototype.match;
try {
  var __instance = new __FACTORY;
  $ERROR('#1: __FACTORY = String.prototype.match; __FACTORY = String.prototype.match; __instance = new __FACTORY lead to throwing exception');
} catch (e) {
  if (e instanceof Test262Error) throw e;
}
