var obj = {
  "1e-7": 1
};
var desc = Object.getOwnPropertyDescriptor(obj, 0.0000001);
assert.sameValue(desc.value, 1, 'desc.value');
