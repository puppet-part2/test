assert.sameValue(Number.prototype.toLocaleString.name, "toLocaleString");
verifyNotEnumerable(Number.prototype.toLocaleString, "name");
verifyNotWritable(Number.prototype.toLocaleString, "name");
verifyConfigurable(Number.prototype.toLocaleString, "name");
