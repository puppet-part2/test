testWithBigIntTypedArrayConstructors(function(TA) {
  assert.throws(TypeError, function() {
    new TA([null]);
  }, "abrupt completion from Null");
});
