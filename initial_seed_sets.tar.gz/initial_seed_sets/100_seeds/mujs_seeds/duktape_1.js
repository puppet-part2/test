Function().apply(1,Array(10000))

// https://github.com/svaarala/duktape/issues/107
