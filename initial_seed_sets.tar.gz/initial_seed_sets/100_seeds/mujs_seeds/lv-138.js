assert.sameValue(Number.NEGATIVE_INFINITY, -Infinity);
