assert.sameValue(Number.isInteger(478), true, 'Number.isInteger(478)');
assert.sameValue(Number.isInteger(-0), true, '-0');
assert.sameValue(Number.isInteger(0), true, '0');
assert.sameValue(Number.isInteger(-1), true, '-1');
assert.sameValue(Number.isInteger(9007199254740991), true, '9007199254740991');
assert.sameValue(Number.isInteger(-9007199254740991), true, '-9007199254740991');
assert.sameValue(Number.isInteger(9007199254740992), true, '9007199254740992');
assert.sameValue(Number.isInteger(-9007199254740992), true, '-9007199254740992');
