verifyProperty(String.prototype, "trimEnd", {
  enumerable: false,
  writable: true,
  configurable: true,
});
