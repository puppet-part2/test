assert.sameValue("\u000D\u000D".trim(), "", '"\u000D\u000D".trim()');
