var obj = {};
var props = new Date();
Object.defineProperty(props, "prop", {
  value: {
    value: 13
  },
  enumerable: true
});
Object.defineProperties(obj, props);
assert(obj.hasOwnProperty("prop"), 'obj.hasOwnProperty("prop") !== true');
assert.sameValue(obj.prop, 13, 'obj.prop');
