var obj = {};
JSON.prop = {
  value: 15
};
Object.defineProperties(obj, JSON);
assert(obj.hasOwnProperty("prop"), 'obj.hasOwnProperty("prop") !== true');
assert.sameValue(obj.prop, 15, 'obj.prop');
