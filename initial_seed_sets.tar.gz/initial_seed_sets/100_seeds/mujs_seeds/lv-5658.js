if (new String("undefined").indexOf(x) !== 0) {
  $ERROR('#1: var x; new String("undefined").indexOf(x) === 0. Actual: ' + new String("undefined").indexOf(x));
}
var x;
