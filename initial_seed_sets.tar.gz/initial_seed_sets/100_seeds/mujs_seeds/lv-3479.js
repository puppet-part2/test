var functionProxy = new Proxy(function() {}, {});
var functionProxyProxy = new Proxy(functionProxy, {});
assert.sameValue(
  Object.prototype.toString.call(functionProxy), '[object Function]', 'function proxy'
);
assert.sameValue(
  Object.prototype.toString.call(functionProxyProxy),
  '[object Function]',
  'proxy for function proxy'
);
var arrowProxy = new Proxy(() => {}, {});
var arrowProxyProxy = new Proxy(arrowProxy, {});
assert.sameValue(
  Object.prototype.toString.call(arrowProxy), '[object Function]', 'arrow function proxy'
);
assert.sameValue(
  Object.prototype.toString.call(arrowProxyProxy),
  '[object Function]',
  'proxy for arrow function proxy'
);
var generatorProxy = new Proxy(function*() {}, {});
var generatorProxyProxy = new Proxy(generatorProxy, {});
assert.sameValue(
  Object.prototype.toString.call(generatorProxy), '[object GeneratorFunction]', 'generator function proxy'
);
assert.sameValue(
  Object.prototype.toString.call(generatorProxyProxy),
  '[object GeneratorFunction]',
  'proxy for generator function proxy'
);
delete generatorProxy.constructor.prototype[Symbol.toStringTag];
assert.sameValue(
  Object.prototype.toString.call(generatorProxy), '[object Function]', 'generator function proxy without Symbol.toStringTag'
);
assert.sameValue(
  Object.prototype.toString.call(generatorProxyProxy),
  '[object Function]',
  'proxy for generator function proxy without Symbol.toStringTag'
);
