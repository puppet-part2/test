testWithAtomicsNonViewValues(function(view) {
  assert.throws(TypeError, function() {
    Atomics.sub(view, 0, 0);
  }, '`Atomics.sub(view, 0, 0)` throws TypeError');
});
