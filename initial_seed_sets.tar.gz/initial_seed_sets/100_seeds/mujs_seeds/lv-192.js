assert.sameValue(Number.prototype.toFixed.name, "toFixed");
verifyNotEnumerable(Number.prototype.toFixed, "name");
verifyNotWritable(Number.prototype.toFixed, "name");
verifyConfigurable(Number.prototype.toFixed, "name");
