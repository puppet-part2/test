var obj = {};
Object.defineProperty(obj, "foo", {
  value: NaN,
  writable: false,
  configurable: false
});
Object.defineProperty(obj, "foo", {
  value: NaN,
  writable: false,
  configurable: false
});
assert.sameValue(obj.foo, NaN);
verifyNotWritable(obj, "foo");
verifyNotEnumerable(obj, "foo");
verifyNotConfigurable(obj, "foo");
