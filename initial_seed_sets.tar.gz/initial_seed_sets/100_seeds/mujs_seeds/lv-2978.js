var obj = {};
var func = function(a, b, c) {
  return arguments;
};
Object.defineProperties(obj, {
  property: {
    writable: func(1, true, "a")
  }
});
obj.property = "isWritable";
assert.sameValue(obj.property, "isWritable", 'obj.property');
